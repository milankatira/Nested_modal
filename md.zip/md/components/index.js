import React, { useState } from "react";
import Child from "./Child";
const index = ({ onClose, show, children, showChildModal }) => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [showChild, setshowChild] = useState(false);

  //   const showChildModal = () => {
  //     setshowChild(!showChild);
  //   };

  if (!show) {
    return null;
  }

  return (
    <div>
      <div className='modal' id='modal'>
        <h2>Modal Window</h2>
        <div className='content'>{children}</div>
        <div className='actions'>
          <button className='toggle-button' onClick={onClose}>
            close
          </button>

          <button
            className='toggle-button'
            id='centered-toggle-button'
            onClick={() => {
              showChildModal(), onClose();
            }}
          >
            show Motttttdal{" "}
          </button>
        </div>
      </div>
    </div>
  );
};

export default index;
