import React from "react";

const Child = ({ onClose, show, children }) => {
  if (!show) {
    return null;
  }

  return (
    <div>
      <div className='modal' id='modal'>
        <h2>Modal Window</h2>
        <div className='content'>{children}</div>
        <div className='actions'>
          <button className='toggle-button' onClick={onClose}>
            close
          </button>
          <p>Lorem ipsum dolor sit amet, consectetur adip</p>
        </div>
      </div>
    </div>
  );
};

export default Child;
