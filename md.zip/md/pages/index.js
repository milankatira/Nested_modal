import React, { useState } from "react";
// import "../styles/styles.css";
import Modal from "../components/index";
import Child from "../components/Child";
const App = () => {
  const [show, setshow] = useState(false);
  const [showChild, setshowChild] = useState(false);

  const showChildModal = () => {
    setshowChild(!showChild);
    showModal();
  };

  const showModal = () => {
    setshow(!show);
  };

  return (
    <div>
      <div>
        <button
          className='toggle-button'
          id='centered-toggle-button'
          onClick={showModal}
        >
          show Parent Modal{" "}
        </button>
        <Modal onClose={showModal} show={show} showChildModal={showChildModal}>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis
          deserunt corrupti, ut fugit magni qui quasi nisi amet repellendus non
          fuga omnis a sed impedit explicabo accusantium nihil doloremque
          consequuntur.
        </Modal>

        <Child onClose={showChildModal} show={showChild}>
          Lorem ipsum dolor sit amet, consectetur adip, Lorem ipsum dolor sit
          amet, consectetur adip. Lorem ipsum dolor sit amet, consectetur
          adipLorem ipsum dolor sit amet, consectetur adipLorem ipsum dolor sit
          amet, consectetur adip
        </Child>
      </div>
    </div>
  );
};

// export default App
export default App;
